export interface ParserData {
    id: number;
    state: string;
    type: string;
    value: string;
}
